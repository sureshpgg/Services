package com.example.response;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"regid",
"regNumber",
"activeFL",
"commPort",
"clientMachineid",
"creditAuthFL",
"hardwareOptions",
"keyboardName",
"receiptType",
"journalType",
"siteHierSiteNo",
"printers",
"deletion",
"updation",
"terminalId",
"clientMachineId"
})
public class Terminal {



@JsonProperty("regid")
private String regid;
public Terminal(String regid, String regNumber, String activeFL, String commPort, String terminalId,
		String clientMachineid, String creditAuthFL, String hardwareOptions, String keyboardName, String receiptType,
		String journalType, String siteHierSiteNo, List<Object> printers, String deletion, String updation) {
	this.regid = regid;
	this.regNumber = regNumber;
	this.activeFL = activeFL;
	this.commPort = commPort;
	this.terminalId = terminalId;
	this.clientMachineid = clientMachineid;
	this.creditAuthFL = creditAuthFL;
	this.hardwareOptions = hardwareOptions;
	this.keyboardName = keyboardName;
	this.receiptType = receiptType;
	this.journalType = journalType;
	this.siteHierSiteNo = siteHierSiteNo;
	this.printers = printers;
	this.deletion = deletion;
	this.updation = updation;
}

@JsonProperty("regNumber")
private String regNumber;
@JsonProperty("activeFL")
private String activeFL;
@JsonProperty("commPort")
private String commPort;
@JsonProperty("terminalId")
private String terminalId;
@JsonProperty("clientMachineid")
private String clientMachineid;
@JsonProperty("creditAuthFL")
private String creditAuthFL;
@JsonProperty("hardwareOptions")
private String hardwareOptions;
@JsonProperty("keyboardName")
private String keyboardName;
@JsonProperty("receiptType")
private String receiptType;
@JsonProperty("journalType")
private String journalType;
@JsonProperty("siteHierSiteNo")
private String siteHierSiteNo;
@JsonProperty("printers")
private List<Object> printers = null;
@JsonProperty("deletion")
private String deletion;
@JsonProperty("updation")
private String updation;


@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("regid")
public String getRegid() {
return regid;
}

@JsonProperty("regid")
public void setRegid(String regid) {
this.regid = regid;
}

@JsonProperty("regNumber")
public String getRegNumber() {
return regNumber;
}

@JsonProperty("regNumber")
public void setRegNumber(String regNumber) {
this.regNumber = regNumber;
}

@JsonProperty("activeFL")
public String getActiveFL() {
return activeFL;
}

@JsonProperty("activeFL")
public void setActiveFL(String activeFL) {
this.activeFL = activeFL;
}

@JsonProperty("commPort")
public String getCommPort() {
return commPort;
}

@JsonProperty("commPort")
public void setCommPort(String commPort) {
this.commPort = commPort;
}
@JsonProperty("terminalId")
public String getTerminalId() {
return terminalId;
}

@JsonProperty("terminalId")
public void setTerminalId(String terminalId) {
this.terminalId = terminalId;
}
@JsonProperty("clientMachineid")
public String getClientMachineid() {
return clientMachineid;
}

@JsonProperty("clientMachineid")
public void setClientMachineid(String clientMachineid) {
this.clientMachineid = clientMachineid;
}

@JsonProperty("creditAuthFL")
public String getCreditAuthFL() {
return creditAuthFL;
}

@JsonProperty("creditAuthFL")
public void setCreditAuthFL(String creditAuthFL) {
this.creditAuthFL = creditAuthFL;
}

@JsonProperty("hardwareOptions")
public String getHardwareOptions() {
return hardwareOptions;
}

@JsonProperty("hardwareOptions")
public void setHardwareOptions(String hardwareOptions) {
this.hardwareOptions = hardwareOptions;
}

@JsonProperty("keyboardName")
public String getKeyboardName() {
return keyboardName;
}

@JsonProperty("keyboardName")
public void setKeyboardName(String keyboardName) {
this.keyboardName = keyboardName;
}

@JsonProperty("receiptType")
public String getReceiptType() {
return receiptType;
}

@JsonProperty("receiptType")
public void setReceiptType(String receiptType) {
this.receiptType = receiptType;
}

@JsonProperty("journalType")
public String getJournalType() {
return journalType;
}

@JsonProperty("journalType")
public void setJournalType(String journalType) {
this.journalType = journalType;
}

@JsonProperty("siteHierSiteNo")
public String getSiteHierSiteNo() {
return siteHierSiteNo;
}

@JsonProperty("siteHierSiteNo")
public void setSiteHierSiteNo(String siteHierSiteNo) {
this.siteHierSiteNo = siteHierSiteNo;
}

@JsonProperty("printers")
public List<Object> getPrinters() {
return printers;
}

@JsonProperty("printers")
public void setPrinters(List<Object> printers) {
this.printers = printers;
}

@JsonProperty("deletion")
public String getDeletion() {
return deletion;
}

@JsonProperty("deletion")
public void setDeletion(String deletion) {
this.deletion = deletion;
}

@JsonProperty("updation")
public String getUpdation() {
return updation;
}

@JsonProperty("updation")
public void setUpdation(String updation) {
this.updation = updation;
}





@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}