package com.example.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.response.Terminal;
import com.example.response.TerminalResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;

@RestController
@RequestMapping("/api/student/")
public class StudentController {

	@Value("${app.name}")
  private  String appname;

	
	
	@GetMapping("/get")
	public TerminalResponse getTerminalResponse() {
		
TerminalResponse response=new TerminalResponse();
response.setSiteNumber("1022");
List<Terminal> terminallist=new ArrayList<Terminal>();


Terminal terminal1=new Terminal("reg67","99","N","Com1",null,"098","Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal2=new Terminal("regee","232","N","Com1",null,null,"Y","Y","OEKBD","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal3=new Terminal("ERTY2","2334","Y","COM1","9900","D7dfg","Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal4=new Terminal("asaaa","324","Y","com1",null,"asd","Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal5=new Terminal("trge","234","N","com1",null,"asd","Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal6=new Terminal("erty","980","N","com1",null,null,"Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");
Terminal terminal7=new Terminal("ERY33","6567","Y","COM1","9000","2342","Y","Y","NAPA","S","N","0",new ArrayList<>() ,"false","false");


terminallist.add(terminal1);
terminallist.add(terminal2);
terminallist.add(terminal3);
terminallist.add(terminal4);
terminallist.add(terminal5);
terminallist.add(terminal6);
terminallist.add(terminal7);


response.setTerminals(terminallist);
		
		
		
		return response;
		
	}
	
}